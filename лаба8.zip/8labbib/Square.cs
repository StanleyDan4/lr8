﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8labbib
{
    public class Square : Rectagle
    {
        public Square(string name, int x, int y, int w) : base(name,x, y, w, w)
        {
        }
    }
}
