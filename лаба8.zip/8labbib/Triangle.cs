﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _8labbib;

namespace _8labib
{
    public class Triangle : Polygon 
    {
        public Triangle(int count = 3) : base(count)
        {

        }
    }
}
